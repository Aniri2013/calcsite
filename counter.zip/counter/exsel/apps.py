from django.apps import AppConfig


class ExselConfig(AppConfig):
    name = 'exsel'
